require 'rails'
require_relative 'fixtures/rails_app'
require 'spec_helper'
RailsApp.initialize!
